package net.ibbxourroygsdb.projectnhilrpgforminecraftjava;

import net.minecraft.class_124;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2398;
import net.minecraft.class_2561;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_3965;
import net.minecraft.class_4970;

/**
 * The Rune Altar: spend a rune shard to convert it into Nhil experience.
 * <p>All work happens on the server only, so multiplayer clients stay in sync.
 */
public class NhilAltarBlock extends class_2248 {
    /** Experience granted for each shard offered. */
    public static final int XP_PER_SHARD = 10;

    public NhilAltarBlock(class_4970.class_2251 settings) {
        super(settings);
    }

    @Override
    protected class_1269 method_55765(class_1799 stack, class_2680 state, class_1937 world, class_2338 pos,
                                         class_1657 player, class_1268 hand, class_3965 hit) {
        if (world.method_8608() || !(player instanceof class_3222 serverPlayer)) {
            return class_1269.field_5812;
        }
        if (!stack.method_31574(NhilContent.RUNE_SHARD)) {
            serverPlayer.method_7353(class_2561.method_43470("The altar hums. Offer a rune shard to awaken it.")
                    .method_27692(class_124.field_1080), true);
            return class_1269.field_5814;
        }

        stack.method_57008(1, serverPlayer);
        NhilProgress.grantExperience(serverPlayer, XP_PER_SHARD, "altar");

        if (world instanceof class_3218 serverWorld) {
            serverWorld.method_8396(null, pos, class_3417.field_26980,
                    class_3419.field_15245, 1.0F, 1.2F);
            serverWorld.method_65096(class_2398.field_11215, pos.method_10263() + 0.5,
                    pos.method_10264() + 1.1, pos.method_10260() + 0.5, 14, 0.4, 0.3, 0.4, 0.02);
        }
        serverPlayer.method_7353(class_2561.method_43470("The rune shard dissolves into " + XP_PER_SHARD + " experience.")
                .method_27692(class_124.field_1075), true);
        return class_1269.field_5812;
    }
}
