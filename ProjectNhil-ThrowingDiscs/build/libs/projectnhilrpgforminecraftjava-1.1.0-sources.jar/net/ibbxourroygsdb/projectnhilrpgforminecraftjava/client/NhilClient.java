package net.ibbxourroygsdb.projectnhilrpgforminecraftjava.client;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.ibbxourroygsdb.projectnhilrpgforminecraftjava.NhilProgress;
import net.minecraft.class_124;
import net.minecraft.class_1657;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_332;

/**
 * Client side only: a small level readout next to the hotbar.
 */
public final class NhilClient implements ClientModInitializer {
    private static final class_2960 HUD_ID =
            class_2960.method_60655("projectnhilrpgforminecraftjava", "progress_hud");

    @Override
    public void onInitializeClient() {
        // Make sure the attachment type this HUD reads is registered on the client too.
        NhilProgress.bootstrap();
        HudElementRegistry.addLast(HUD_ID, (context, tickCounter) -> render(context));
    }

    private static void render(class_332 context) {
        class_310 client = class_310.method_1551();
        class_1657 player = client.field_1724;
        if (player == null || client.field_1690.field_1842 || client.field_1755 != null) {
            return;
        }
        NhilProgress progress = player.getAttached(NhilProgress.ATTACHMENT);
        if (progress == null) {
            return;
        }

        int width = context.method_51421();
        int height = context.method_51443();
        int x = width / 2 - 91;
        int y = height - 46;

        class_2561 label = class_2561.method_43470("Lv " + progress.level())
                .method_27692(class_124.field_1065);
        context.method_27535(client.field_1772, label, x, y, 0xFFFFFF);

        // Slim experience bar so the next level is always readable at a glance.
        int needed = progress.experienceToNextLevel();
        if (needed > 0) {
            int barWidth = 60;
            int filled = Math.min(barWidth, (progress.experience() * barWidth) / needed);
            context.method_25294(x, y + 10, x + barWidth, y + 12, 0x44000000);
            if (filled > 0) {
                context.method_25294(x, y + 10, x + filled, y + 12, 0xFFAA00AA);
            }
        } else {
            context.method_27535(client.field_1772,
                    class_2561.method_43470("Max").method_27692(class_124.field_1076), x + 20, y, 0xFFFFFF);
        }

        if (progress.relics() > 0) {
            context.method_27535(client.field_1772,
                    class_2561.method_43470("Relics " + progress.relics()).method_27692(class_124.field_1075),
                    x, y - 10, 0xFFFFFF);
        }
    }
}
