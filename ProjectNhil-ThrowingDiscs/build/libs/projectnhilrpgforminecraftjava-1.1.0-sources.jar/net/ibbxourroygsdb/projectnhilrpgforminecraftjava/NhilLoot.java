package net.ibbxourroygsdb.projectnhilrpgforminecraftjava;

import java.util.List;

import net.fabricmc.fabric.api.loot.v3.LootTableEvents;
import net.minecraft.class_219;
import net.minecraft.class_2960;
import net.minecraft.class_44;
import net.minecraft.class_52;
import net.minecraft.class_55;
import net.minecraft.class_77;

/**
 * Adds ruin-themed loot to vanilla abandoned structures, so exploring pays off.
 */
public final class NhilLoot {
    private NhilLoot() {
    }

    /** Chest tables that should sometimes contain a rune shard. */
    private static final List<String> RUIN_CHESTS = List.of(
            "chests/ruined_portal",
            "chests/desert_pyramid",
            "chests/jungle_temple",
            "chests/igloo_chest",
            "chests/shipwreck_treasure",
            "chests/simple_dungeon",
            "chests/abandoned_mineshaft",
            "chests/pillager_outpost",
            "chests/ancient_city");

    private static final List<String> TREASURE_CHESTS = List.of(
            "chests/buried_treasure",
            "chests/ancient_city",
            "chests/trial_chambers/reward_ominous_unique",
            "chests/stronghold_library");

    public static void register() {
        LootTableEvents.MODIFY.register((key, tableBuilder, source, registries) -> {
            if (!source.isBuiltin()) {
                return;
            }
            class_2960 id = key.method_29177();
            if (!"minecraft".equals(id.method_12836())) {
                return;
            }
            String path = id.method_12832();
            if (RUIN_CHESTS.contains(path)) {
                addPool(tableBuilder, NhilContent.RUNE_SHARD, 0.35F, 1, 3);
                addPool(tableBuilder, NhilContent.RUNE_TONIC, 0.20F, 1, 2);
            }
            if (TREASURE_CHESTS.contains(path)) {
                addPool(tableBuilder, NhilContent.ANCIENT_RELIC, 0.25F, 1, 1);
            }
        });
    }

    private static void addPool(class_52.class_53 builder,
                                net.minecraft.class_1792 item,
                                float chance,
                                int min,
                                int max) {
        class_55.class_56 pool = class_55.method_347()
                .method_352(class_44.method_32448(min))
                .method_356(class_219.method_932(chance))
                .method_351(class_77.method_411(item));
        if (max > min) {
            pool.method_35509(class_44.method_32448(max - min));
        }
        builder.method_336(pool);
    }
}
