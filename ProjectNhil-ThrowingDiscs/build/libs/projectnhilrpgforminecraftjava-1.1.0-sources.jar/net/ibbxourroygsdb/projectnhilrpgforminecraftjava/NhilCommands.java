package net.ibbxourroygsdb.projectnhilrpgforminecraftjava;

import java.util.Collection;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.IntegerArgumentType;

import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.minecraft.class_124;
import net.minecraft.class_2168;
import net.minecraft.class_2170;
import net.minecraft.class_2561;
import net.minecraft.class_3222;

/**
 * The {@code nhil} command tree.
 *
 * <p>The root literal has no permission gate so the server console can always read status.
 */
public final class NhilCommands {
    private NhilCommands() {
    }

    public static void register() {
        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) ->
                register(dispatcher));
    }

    private static void register(CommandDispatcher<class_2168> dispatcher) {
        dispatcher.register(class_2170.method_9247("nhil")
                .executes(ctx -> status(ctx.getSource()))
                .then(class_2170.method_9247("status")
                        .executes(ctx -> status(ctx.getSource())))
                .then(class_2170.method_9247("landmarks")
                        .executes(ctx -> landmarks(ctx.getSource())))
                .then(class_2170.method_9247("progress")
                        .executes(ctx -> progress(ctx.getSource())))
                .then(class_2170.method_9247("ranks")
                        .executes(ctx -> ranks(ctx.getSource())))
                .then(class_2170.method_9247("grant")
                        .requires(class_2170.method_71774(class_2170.field_31839))
                        .then(class_2170.method_9244("amount", IntegerArgumentType.integer(1, 500))
                                .executes(ctx -> grant(ctx.getSource(),
                                        IntegerArgumentType.getInteger(ctx, "amount")))))
                .then(class_2170.method_9247("relic")
                        .requires(class_2170.method_71774(class_2170.field_31839))
                        .executes(ctx -> relic(ctx.getSource()))));
    }

    private static int status(class_2168 source) {
        source.method_9226(() -> class_2561.method_43470("Project Nhil RPG")
                .method_27692(class_124.field_1065), false);
        source.method_9226(() -> class_2561.method_43470("Levels need " + NhilProgress.XP_PER_LEVEL
                + " experience at first, rising by " + NhilProgress.XP_STEP
                + " each level, maximum level " + NhilProgress.MAX_LEVEL).method_27692(class_124.field_1080), false);
        source.method_9226(() -> class_2561.method_43470("Earn experience by exploring ruins, salvaging ruin blocks, "
                + "fighting monsters and surviving their blows.").method_27692(class_124.field_1080), false);
        source.method_9226(() -> class_2561.method_43470("Use /nhil landmarks to list the tracked sites.")
                .method_27692(class_124.field_1080), false);
        return 1;
    }

    private static int landmarks(class_2168 source) {
        var names = NhilGameplay.landmarkNames();
        source.method_9226(() -> class_2561.method_43470("Tracked landmarks (" + names.size() + ")")
                .method_27692(class_124.field_1065), false);
        for (String name : names) {
            source.method_9226(() -> class_2561.method_43470(" - " + WayfinderCompassItem.prettify(name))
                    .method_27692(class_124.field_1080), false);
        }
        return names.size();
    }

    private static int ranks(class_2168 source) {
        var titles = NhilProgress.rankNames();
        source.method_9226(() -> class_2561.method_43470("Nhil ranks (" + titles.size() + ")")
                .method_27692(class_124.field_1065), false);
        for (String title : titles) {
            source.method_9226(() -> class_2561.method_43470(" - " + title).method_27692(class_124.field_1080), false);
        }
        return titles.size();
    }

    private static int progress(class_2168 source) {
        class_3222 player = source.method_44023();
        if (player == null) {
            source.method_9226(() -> class_2561.method_43470("/nhil progress needs a player. "
                    + "Run it in game instead.").method_27692(class_124.field_1080), false);
            return 1;
        }
        NhilProgress progress = NhilProgress.of(player);
        source.method_9226(() -> class_2561.method_43470(progress.rank() + "  |  level " + progress.level()
                + "  |  experience " + progress.experience() + "/" + progress.experienceToNextLevel())
                .method_27692(class_124.field_1065), false);
        source.method_9226(() -> class_2561.method_43470("Relics " + progress.relics()
                + "  |  landmarks " + progress.discoveries().size())
                .method_27692(class_124.field_1080), false);
        return progress.level();
    }

    private static int grant(class_2168 source, int amount) {
        Collection<class_3222> players = source.method_9211().method_3760().method_14571();
        if (players.isEmpty()) {
            source.method_9226(() -> class_2561.method_43470("No players online to receive experience.")
                    .method_27692(class_124.field_1080), false);
            return 1;
        }
        for (class_3222 player : players) {
            NhilProgress.grantExperience(player, amount, "reward");
        }
        source.method_9226(() -> class_2561.method_43470("Granted " + amount + " Nhil experience to "
                + players.size() + " player(s).").method_27692(class_124.field_1060), false);
        return players.size();
    }

    private static int relic(class_2168 source) {
        Collection<class_3222> players = source.method_9211().method_3760().method_14571();
        if (players.isEmpty()) {
            source.method_9226(() -> class_2561.method_43470("No players online to receive a relic.")
                    .method_27692(class_124.field_1080), false);
            return 1;
        }
        for (class_3222 player : players) {
            player.method_7270(new net.minecraft.class_1799(NhilContent.ANCIENT_RELIC));
            NhilProgress.registerRelic(player, 1);
        }
        source.method_9226(() -> class_2561.method_43470("Handed out an ancient relic to "
                + players.size() + " player(s).").method_27692(class_124.field_1060), false);
        return players.size();
    }
}
