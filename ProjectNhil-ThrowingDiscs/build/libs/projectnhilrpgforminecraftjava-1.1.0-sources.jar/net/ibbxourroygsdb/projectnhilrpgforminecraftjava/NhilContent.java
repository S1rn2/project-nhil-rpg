package net.ibbxourroygsdb.projectnhilrpgforminecraftjava;

import java.util.List;

import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.minecraft.class_1747;
import net.minecraft.class_1761;
import net.minecraft.class_1792;
import net.minecraft.class_1814;
import net.minecraft.class_2248;
import net.minecraft.class_2378;
import net.minecraft.class_2498;
import net.minecraft.class_2960;
import net.minecraft.class_4970;
import net.minecraft.class_5321;
import net.minecraft.class_7923;
import net.minecraft.class_7924;
import net.minecraft.class_9886;

/**
 * Items and blocks added by the mod.
 *
 * <p>All art is reused from vanilla textures so the content always renders.
 */
public final class NhilContent {
    private NhilContent() {
    }

    // ------------------------------------------------------------------
    // Blocks
    // ------------------------------------------------------------------

    public static final class_5321<class_2248> RUIN_BRICK_KEY = blockKey("ruin_brick");
    public static final class_2248 RUIN_BRICK = BlockAccess.register(RUIN_BRICK_KEY,
            class_4970.class_2251.method_9637()
                    .method_63500(RUIN_BRICK_KEY)
                    .method_9629(1.6F, 6.0F)
                    .method_29292()
                    .method_9626(class_2498.field_11544));

    public static final class_5321<class_2248> MOSSY_RUIN_BRICK_KEY = blockKey("mossy_ruin_brick");
    public static final class_2248 MOSSY_RUIN_BRICK = BlockAccess.register(MOSSY_RUIN_BRICK_KEY,
            class_4970.class_2251.method_9637()
                    .method_63500(MOSSY_RUIN_BRICK_KEY)
                    .method_9629(1.8F, 6.0F)
                    .method_29292()
                    .method_9626(class_2498.field_11544));

    public static final class_5321<class_2248> DEEP_RUIN_TILE_KEY = blockKey("deep_ruin_tile");
    public static final class_2248 DEEP_RUIN_TILE = BlockAccess.register(DEEP_RUIN_TILE_KEY,
            class_4970.class_2251.method_9637()
                    .method_63500(DEEP_RUIN_TILE_KEY)
                    .method_9629(2.2F, 9.0F)
                    .method_29292()
                    .method_9626(class_2498.field_29035));

    public static final class_5321<class_2248> RUNE_LAMP_KEY = blockKey("rune_lamp");
    public static final class_2248 RUNE_LAMP = BlockAccess.register(RUNE_LAMP_KEY,
            class_4970.class_2251.method_9637()
                    .method_63500(RUNE_LAMP_KEY)
                    .method_9629(2.0F, 9.0F)
                    .method_29292()
                    .method_9631(state -> 12)
                    .method_9626(class_2498.field_27197));

    public static final class_5321<class_2248> RUNE_ALTAR_KEY = blockKey("rune_altar");
    public static final class_2248 RUNE_ALTAR = BlockAccess.register(RUNE_ALTAR_KEY,
            class_4970.class_2251.method_9637()
                    .method_63500(RUNE_ALTAR_KEY)
                    .method_9629(2.4F, 9.0F)
                    .method_29292()
                    .method_9631(state -> 7)
                    .method_9626(class_2498.field_29035),
            NhilAltarBlock::new);

    // ------------------------------------------------------------------
    // Items
    // ------------------------------------------------------------------

    public static final class_1792 RUNE_SHARD = simpleItem("rune_shard",
            new class_1792.class_1793().method_7894(class_1814.field_8907));

    public static final class_1792 ANCIENT_RELIC = simpleItem("ancient_relic",
            new class_1792.class_1793().method_7894(class_1814.field_8903).method_7889(16));

    public static final class_1792 WAYFINDER_COMPASS = ItemAccess.register("wayfinder_compass",
            new class_1792.class_1793().method_7894(class_1814.field_8907).method_7889(1),
            WayfinderCompassItem::new);

    public static final class_1792 RUNE_TONIC = simpleItem("rune_tonic",
            NhilConsumables.runeTonic(new class_1792.class_1793().method_7894(class_1814.field_8907).method_7889(8)));

    public static final class_1792 NHIL_BLADE = ItemAccess.register("nhil_blade",
            new class_1792.class_1793().method_7894(class_1814.field_8903).method_7889(1)
                    .method_66333(class_9886.field_52588, 3.0F, -2.4F),
            NhilBladeItem::new);

    public static final List<class_1792> RELICS = List.of(RUNE_SHARD, ANCIENT_RELIC);

    // ------------------------------------------------------------------
    // Registration helpers
    // ------------------------------------------------------------------

    private static class_5321<class_2248> blockKey(String name) {
        return class_5321.method_29179(class_7924.field_41254, class_2960.method_60655(PGPlugin.MOD_ID, name));
    }

    private static class_5321<class_1792> itemKey(String name) {
        return class_5321.method_29179(class_7924.field_41197, class_2960.method_60655(PGPlugin.MOD_ID, name));
    }

    private static class_1792 simpleItem(String name, class_1792.class_1793 settings) {
        class_5321<class_1792> key = itemKey(name);
        return class_2378.method_39197(class_7923.field_41178, key, new class_1792(settings.method_63686(key)));
    }

    private static void registerBlockItem(class_5321<class_2248> blockKey, class_2248 block) {
        class_5321<class_1792> key = itemKey(blockKey.method_29177().method_12832());
        class_2378.method_39197(class_7923.field_41178, key, new class_1747(block, new class_1792.class_1793().method_63686(key)));
    }

    /** Tiny indirection so the static field initialisers above stay readable. */
    static final class BlockAccess {
        private BlockAccess() {
        }

        static class_2248 register(class_5321<class_2248> key, class_4970.class_2251 settings) {
            return class_2378.method_39197(class_7923.field_41175, key, new class_2248(settings));
        }

        static class_2248 register(class_5321<class_2248> key,
                              class_4970.class_2251 settings,
                              java.util.function.Function<class_4970.class_2251, class_2248> factory) {
            return class_2378.method_39197(class_7923.field_41175, key, factory.apply(settings));
        }
    }

    /** Item factory variant that needs a custom class. */
    static final class ItemAccess {
        private ItemAccess() {
        }

        static class_1792 register(String name, class_1792.class_1793 settings, java.util.function.Function<class_1792.class_1793, class_1792> factory) {
            class_5321<class_1792> key = itemKey(name);
            return class_2378.method_39197(class_7923.field_41178, key, factory.apply(settings.method_63686(key)));
        }
    }

    // ------------------------------------------------------------------
    // Entry point
    // ------------------------------------------------------------------

    public static void initialize() {
        registerBlockItem(RUIN_BRICK_KEY, RUIN_BRICK);
        registerBlockItem(MOSSY_RUIN_BRICK_KEY, MOSSY_RUIN_BRICK);
        registerBlockItem(DEEP_RUIN_TILE_KEY, DEEP_RUIN_TILE);
        registerBlockItem(RUNE_LAMP_KEY, RUNE_LAMP);
        registerBlockItem(RUNE_ALTAR_KEY, RUNE_ALTAR);

        ItemGroupEvents.modifyEntriesEvent(group("building_blocks")).register(entries -> {
            entries.method_45421(RUIN_BRICK);
            entries.method_45421(MOSSY_RUIN_BRICK);
            entries.method_45421(DEEP_RUIN_TILE);
            entries.method_45421(RUNE_LAMP);
            entries.method_45421(RUNE_ALTAR);
        });
        ItemGroupEvents.modifyEntriesEvent(group("ingredients")).register(entries -> {
            entries.method_45421(RUNE_SHARD);
            entries.method_45421(ANCIENT_RELIC);
        });
        ItemGroupEvents.modifyEntriesEvent(group("food_and_drinks"))
                .register(entries -> entries.method_45421(RUNE_TONIC));
        ItemGroupEvents.modifyEntriesEvent(group("tools_and_utilities"))
                .register(entries -> entries.method_45421(WAYFINDER_COMPASS));
        ItemGroupEvents.modifyEntriesEvent(group("combat")).register(entries -> entries.method_45421(NHIL_BLADE));
    }

    /**
     * Vanilla item group keys are private in 1.21.11, so build the well known ids directly.
     */
    private static class_5321<class_1761> group(String path) {
        return class_5321.method_29179(class_7924.field_44688, class_2960.method_60656(path));
    }
}
