package net.ibbxourroygsdb.projectnhilrpgforminecraftjava;

import java.util.List;

import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.fabricmc.fabric.api.entity.event.v1.ServerPlayerEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.event.player.PlayerBlockBreakEvents;
import net.minecraft.class_124;
import net.minecraft.class_1282;
import net.minecraft.class_1569;
import net.minecraft.class_1799;
import net.minecraft.class_2338;
import net.minecraft.class_2378;
import net.minecraft.class_2561;
import net.minecraft.class_2680;
import net.minecraft.class_2960;
import net.minecraft.class_3195;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3449;
import net.minecraft.class_5321;
import net.minecraft.class_7058;
import net.minecraft.class_7924;

/**
 * Wires the RPG progression into normal play: exploring, fighting and salvaging.
 */
public final class NhilGameplay {
    private NhilGameplay() {
    }

    /** How often (in ticks) a player's position is checked for a new ruin. */
    private static final int DISCOVERY_INTERVAL = 40;

    /** Ruins and abandoned sites worth recording. */
    private static final List<class_5321<class_3195>> LANDMARKS = List.of(
            class_7058.field_37192,
            class_7058.field_43326,
            class_7058.field_37173,
            class_7058.field_37172,
            class_7058.field_37174,
            class_7058.field_37177,
            class_7058.field_37168,
            class_7058.field_38428,
            class_7058.field_47411,
            class_7058.field_37175,
            class_7058.field_37185,
            class_7058.field_37178,
            class_7058.field_37169);

    private static int tickCounter;

    public static void register() {
        // Load and repair progress when a player joins.
        ServerPlayerEvents.JOIN.register(player -> {
            NhilProgress progress = NhilProgress.of(player);
            NhilProgress.syncHealth(player, progress.level());
            if (progress.level() > 1 || progress.relics() > 0) {
                player.method_7353(class_2561.method_43470(progress.rank() + "  |  level " + progress.level()
                                + "  |  relics " + progress.relics()
                                + "  |  landmarks " + progress.discoveries().size())
                        .method_27692(class_124.field_1080), false);
            }
        });

        // Restore the health bonus after a respawn.
        ServerPlayerEvents.AFTER_RESPAWN.register((oldPlayer, newPlayer, alive) -> {
            NhilProgress progress = NhilProgress.of(newPlayer);
            NhilProgress.syncHealth(newPlayer, progress.level());
        });

        // Exploring: cheap positional check, never a cube scan.
        ServerTickEvents.END_SERVER_TICK.register(server -> {
            if (++tickCounter < DISCOVERY_INTERVAL) {
                return;
            }
            tickCounter = 0;
            for (class_3218 world : server.method_3738()) {
                for (class_3222 player : world.method_18456()) {
                    checkLandmark(world, player);
                }
            }
        });

        // Salvaging ruin materials slowly teaches the player.
        PlayerBlockBreakEvents.AFTER.register((world, player, pos, state, blockEntity) -> {
            if (world.method_8608() || !(player instanceof class_3222 serverPlayer)) {
                return;
            }
            if (isRuinBlock(state)) {
                NhilProgress.grantExperience(serverPlayer, 1, "salvage");
            }
        });

        // Fighting: defeating monsters feeds progression and can drop a rune shard.
        ServerLivingEntityEvents.AFTER_DEATH.register((entity, source) -> {
            if (!(entity instanceof class_1569)) {
                return;
            }
            class_3222 killer = killerOf(source);
            if (killer == null) {
                return;
            }
            NhilProgress.grantExperience(killer, 2, "hunt");
            float roll = entity.method_59922().method_43057();
            if (roll < 0.2F) {
                class_1799 shard = new class_1799(NhilContent.RUNE_SHARD);
                if (!killer.method_31548().method_7394(shard)) {
                    killer.method_7328(shard, false);
                }
                killer.method_7353(class_2561.method_43470("A rune shard clatters loose.")
                        .method_27692(class_124.field_1075), true);
            } else if (roll < 0.26F) {
                class_1799 tonic = new class_1799(NhilContent.RUNE_TONIC);
                if (!killer.method_31548().method_7394(tonic)) {
                    killer.method_7328(tonic, false);
                }
                killer.method_7353(class_2561.method_43470("A rune tonic spills from the corpse.")
                        .method_27692(class_124.field_1060), true);
            }
        });

        // Danger pays: a solid blow from a monster teaches the player something.
        ServerLivingEntityEvents.AFTER_DAMAGE.register((entity, source, base, taken, blocked) -> {
            if (!(entity instanceof class_3222 player) || taken < 4.0F) {
                return;
            }
            if (source.method_5529() instanceof class_1569 && player.method_59922().method_43057() < 0.25F) {
                NhilProgress.grantExperience(player, 1, "endurance");
            }
        });
    }

    private static class_3222 killerOf(class_1282 source) {
        if (source.method_5529() instanceof class_3222 player) {
            return player;
        }
        return null;
    }

    private static boolean isRuinBlock(class_2680 state) {
        return state.method_27852(NhilContent.RUIN_BRICK)
                || state.method_27852(NhilContent.MOSSY_RUIN_BRICK)
                || state.method_27852(NhilContent.DEEP_RUIN_TILE)
                || state.method_27852(NhilContent.RUNE_LAMP)
                || state.method_27852(NhilContent.RUNE_ALTAR);
    }

    private static void checkLandmark(class_3218 world, class_3222 player) {
        try {
            class_2378<class_3195> registry = world.method_30349().method_30530(class_7924.field_41246);
            class_2338 pos = player.method_24515();
            for (class_5321<class_3195> key : LANDMARKS) {
                class_3195 structure = registry.method_31189(key).orElse(null);
                if (structure == null) {
                    continue;
                }
                class_3449 start = world.method_27056().method_28388(pos, structure);
                if (start == null || !start.method_16657()) {
                    continue;
                }
                class_2960 id = key.method_29177();
                if (NhilProgress.registerDiscovery(player, id.toString())) {
                    player.method_7353(class_2561.method_43470("Landmark discovered: " + WayfinderCompassItem.prettify(id.method_12832()))
                            .method_27692(class_124.field_1065), false);
                    player.method_7353(class_2561.method_43470("+6 Nhil experience").method_27692(class_124.field_1080), true);
                    NhilProgress.grantExperience(player, 6, "exploration");
                }
                return;
            }
        } catch (RuntimeException exception) {
            PGPlugin.LOGGER.warn("Landmark check failed for {}", player.method_5477().getString(), exception);
        }
    }

    /** Read-only view used by the status command. */
    public static List<String> landmarkNames() {
        return LANDMARKS.stream().map(key -> key.method_29177().method_12832()).toList();
    }
}
