package net.ibbxourroygsdb.projectnhilrpgforminecraftjava;

import java.util.ArrayList;
import java.util.List;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;

import net.fabricmc.fabric.api.attachment.v1.AttachmentRegistry;
import net.fabricmc.fabric.api.attachment.v1.AttachmentType;
import net.minecraft.class_124;
import net.minecraft.class_1322;
import net.minecraft.class_1324;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_3222;
import net.minecraft.class_5134;

/**
 * Persistent adventuring progress for a single player.
 *
 * <p>Stored through a Fabric data attachment so it survives relogging, server restarts and death.
 */
public final class NhilProgress {
    /** Experience needed to advance from level 1 to level 2. */
    public static final int XP_PER_LEVEL = 15;
    /** Extra experience each further level demands. */
    public static final int XP_STEP = 2;
    /** Highest level a wanderer can reach. */
    public static final int MAX_LEVEL = 20;

    /** Adventuring ranks, from the first steps to the endgame. */
    private static final String[][] RANKS = {
            {"Wanderer", "1"},
            {"Delver", "3"},
            {"Ruin Seeker", "6"},
            {"Relic Hunter", "10"},
            {"Nhil Warden", "15"},
            {"Nhil Ascendant", "20"},
    };
    public static final class_2960 HEALTH_MODIFIER_ID =
            class_2960.method_60655(PGPlugin.MOD_ID, "level_vitality");

    public static final Codec<NhilProgress> CODEC = RecordCodecBuilder.create(instance -> instance.group(
            Codec.INT.fieldOf("level").forGetter(NhilProgress::level),
            Codec.INT.fieldOf("experience").forGetter(NhilProgress::experience),
            Codec.INT.fieldOf("relics").forGetter(NhilProgress::relics),
            Codec.STRING.listOf().fieldOf("discoveries").forGetter(NhilProgress::discoveries)
    ).apply(instance, NhilProgress::new));

    public static final AttachmentType<NhilProgress> ATTACHMENT = AttachmentRegistry
            .<NhilProgress>builder()
            .persistent(CODEC)
            .copyOnDeath()
            .syncWith(net.minecraft.class_9135.method_56896(CODEC),
                    net.fabricmc.fabric.api.attachment.v1.AttachmentSyncPredicate.all())
            .buildAndRegister(class_2960.method_60655(PGPlugin.MOD_ID, "progress"));

    private final int level;
    private final int experience;
    private final int relics;
    private final List<String> discoveries;

    public NhilProgress(int level, int experience, int relics, List<String> discoveries) {
        this.level = Math.max(1, Math.min(MAX_LEVEL, level));
        this.experience = Math.max(0, experience);
        this.relics = Math.max(0, relics);
        this.discoveries = List.copyOf(discoveries);
    }

    public static NhilProgress fresh() {
        return new NhilProgress(1, 0, 0, List.of());
    }

    /** Forces this class to load so the attachment type is registered before the registries freeze. */
    public static void bootstrap() {
        if (ATTACHMENT == null) {
            throw new IllegalStateException("attachment type failed to register");
        }
    }

    public int level() {
        return this.level;
    }

    public int experience() {
        return this.experience;
    }

    public int relics() {
        return this.relics;
    }

    public List<String> discoveries() {
        return this.discoveries;
    }

    /** Experience still needed before the next level. */
    public int experienceToNextLevel() {
        return xpForLevel(this.level);
    }

    /** Experience required to advance out of the given level. */
    public static int xpForLevel(int level) {
        if (level >= MAX_LEVEL) {
            return 0;
        }
        return XP_PER_LEVEL + (Math.max(1, level) - 1) * XP_STEP;
    }

    /** Adventuring title that matches the current level. */
    public String rank() {
        return rankForLevel(this.level);
    }

    /** Adventuring title for any level, from Wanderer to Nhil Ascendant. */
    public static String rankForLevel(int level) {
        String title = RANKS[0][0];
        for (String[] rank : RANKS) {
            if (level >= Integer.parseInt(rank[1])) {
                title = rank[0];
            }
        }
        return title;
    }

    /** Every rank and the level that unlocks it, in ascending order. */
    public static List<String> rankNames() {
        List<String> names = new ArrayList<>();
        for (String[] rank : RANKS) {
            names.add(rank[0] + " (level " + rank[1] + ")");
        }
        return names;
    }

    public NhilProgress withExperience(int amount) {
        return new NhilProgress(this.level, amount, this.relics, this.discoveries);
    }

    public NhilProgress withLevel(int value) {
        return new NhilProgress(value, this.experience, this.relics, this.discoveries);
    }

    public NhilProgress withRelics(int value) {
        return new NhilProgress(this.level, this.experience, value, this.discoveries);
    }

    public NhilProgress withDiscoveries(List<String> values) {
        return new NhilProgress(this.level, this.experience, this.relics, values);
    }

    public boolean knows(String discovery) {
        return this.discoveries.contains(discovery);
    }

    // ------------------------------------------------------------------
    // Helpers
    // ------------------------------------------------------------------

    public static NhilProgress of(class_3222 player) {
        return player.getAttachedOrCreate(ATTACHMENT, NhilProgress::fresh);
    }

    public static void store(class_3222 player, NhilProgress progress) {
        player.setAttached(ATTACHMENT, progress);
        syncHealth(player, progress.level());
    }

    /**
     * Grants experience, handling any number of level ups, and reports them to the player.
     */
    public static void grantExperience(class_3222 player, int amount, String reason) {
        if (amount <= 0) {
            return;
        }
        NhilProgress progress = of(player);
        int total = progress.experience() + amount;
        int level = progress.level();
        String oldRank = rankForLevel(level);
        while (level < MAX_LEVEL && total >= xpForLevel(level)) {
            total -= xpForLevel(level);
            level++;
        }
        if (level >= MAX_LEVEL) {
            total = 0;
        }
        NhilProgress updated = new NhilProgress(level, total, progress.relics(), progress.discoveries());
        store(player, updated);

        if (level > progress.level()) {
            String newRank = rankForLevel(level);
            player.method_7353(class_2561.method_43470("Nhil level " + level + " reached")
                    .method_27692(class_124.field_1065)
                    .method_10852(class_2561.method_43470(" (" + reason + ")").method_27692(class_124.field_1080)), false);
            player.method_7353(class_2561.method_43470("Your vitality grows. Maximum health increased.")
                    .method_27692(class_124.field_1054), true);
            if (!newRank.equals(oldRank)) {
                player.method_7353(class_2561.method_43470("Rank earned: " + newRank)
                        .method_27692(class_124.field_1075), false);
            }
        } else if (amount >= 5) {
            player.method_7353(class_2561.method_43470("+" + amount + " Nhil experience")
                    .method_27692(class_124.field_1080), true);
        }
    }

    /** Applies the permanent max health bonus that scales with level. */
    public static void syncHealth(class_3222 player, int level) {
        class_1324 health = player.method_5996(class_5134.field_23716);
        if (health == null) {
            return;
        }
        health.method_6200(HEALTH_MODIFIER_ID);
        if (level > 1) {
            health.method_26837(new class_1322(
                    HEALTH_MODIFIER_ID, level - 1, class_1322.class_1323.field_6328));
        }
    }

    public static void registerRelic(class_3222 player, int amount) {
        NhilProgress progress = of(player);
        store(player, progress.withRelics(progress.relics() + amount));
    }

    public static boolean registerDiscovery(class_3222 player, String discovery) {
        NhilProgress progress = of(player);
        if (progress.knows(discovery)) {
            return false;
        }
        List<String> known = new ArrayList<>(progress.discoveries());
        known.add(discovery);
        store(player, progress.withDiscoveries(known));
        return true;
    }
}
