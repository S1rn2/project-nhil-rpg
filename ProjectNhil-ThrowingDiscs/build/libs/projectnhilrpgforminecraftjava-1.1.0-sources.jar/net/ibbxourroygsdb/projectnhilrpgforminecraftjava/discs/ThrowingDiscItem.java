package net.ibbxourroygsdb.projectnhilrpgforminecraftjava.discs;

import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_3417;
import net.minecraft.class_3419;

public class ThrowingDiscItem extends class_1792 {
    private final DiscTier tier;

    public ThrowingDiscItem(DiscTier tier, class_1792.class_1793 settings) {
        super(settings);
        this.tier = tier;
    }

    @Override
    public class_1269 method_7836(class_1937 world, class_1657 user, class_1268 hand) {
        if (world.method_8608()) {
            return class_1269.field_5812;
        }
        class_1799 held = user.method_5998(hand);
        ThrowingDiscEntity disc = new ThrowingDiscEntity(ThrowingDiscsContent.DISC_ENTITY, world);
        disc.launch(user, held.method_46651(1), tier);
        // The disc item rides inside the entity and comes back to the thrower when caught.
        held.method_7934(1);
        world.method_8649(disc);
        world.method_8396(null, user.method_24515(), class_3417.field_14706,
                class_3419.field_15248, 0.6F, tier.pitch);
        return class_1269.field_5812;
    }
}
