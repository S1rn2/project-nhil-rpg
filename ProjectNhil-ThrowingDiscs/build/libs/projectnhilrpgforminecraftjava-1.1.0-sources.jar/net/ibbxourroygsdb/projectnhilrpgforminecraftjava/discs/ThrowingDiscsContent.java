package net.ibbxourroygsdb.projectnhilrpgforminecraftjava.discs;

import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.minecraft.class_1299;
import net.minecraft.class_1311;
import net.minecraft.class_1761;
import net.minecraft.class_1792;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_5321;
import net.minecraft.class_7923;
import net.minecraft.class_7924;

/**
 * Registers the throwing discs. Items and the entity keep the original "throwingdiscs" namespace so
 * item ids and recipes stay the same as in the standalone Throwing Discs mod.
 */
public final class ThrowingDiscsContent {
    public static final String NAMESPACE = "throwingdiscs";

    public static class_1299<ThrowingDiscEntity> DISC_ENTITY;

    private ThrowingDiscsContent() {
    }

    public static class_2960 id(String path) {
        return class_2960.method_60655(NAMESPACE, path);
    }

    public static void initialize() {
        class_5321<class_1299<?>> entityKey = class_5321.method_29179(class_7924.field_41266, id("throwing_disc"));
        DISC_ENTITY = class_2378.method_39197(class_7923.field_41177, entityKey,
                class_1299.class_1300.<ThrowingDiscEntity>method_5903(ThrowingDiscEntity::new, class_1311.field_17715)
                        .method_17687(0.25F, 0.25F)
                        .method_27299(64)
                        .method_27300(1)
                        .method_5905(entityKey));

        for (DiscTier tier : DiscTier.values()) {
            class_5321<class_1792> key = class_5321.method_29179(class_7924.field_41197, id(tier.id + "_throwing_disc"));
            tier.item = class_2378.method_39197(class_7923.field_41178, key,
                    new ThrowingDiscItem(tier, new class_1792.class_1793().method_63686(key).method_7895(tier.durability)));
        }

        // Vanilla ItemGroups constants are private in 1.21.11, so build the key from its id (same as NhilContent).
        class_5321<class_1761> combat = class_5321.method_29179(class_7924.field_44688, class_2960.method_60656("combat"));
        ItemGroupEvents.modifyEntriesEvent(combat).register(entries -> {
            for (DiscTier tier : DiscTier.values()) {
                entries.method_45421(tier.item);
            }
        });
    }
}
