package net.ibbxourroygsdb.projectnhilrpgforminecraftjava.discs;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import net.minecraft.class_11368;
import net.minecraft.class_11372;
import net.minecraft.class_1282;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1309;
import net.minecraft.class_1542;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_2680;
import net.minecraft.class_2940;
import net.minecraft.class_2943;
import net.minecraft.class_2945;
import net.minecraft.class_3218;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_3856;

/**
 * A thrown disc. It flies straight with no gravity, ricochets off blocks (each bounce extends the
 * outward flight), damages every mob it passes through, then homes back to its owner.
 *
 * <p>Performance: all logic runs server side only, one entity query and at most four block lookups
 * per tick per disc, and blocks in unloaded chunks are treated as walls so a disc can never force
 * a chunk load.
 */
public class ThrowingDiscEntity extends class_1297 implements class_3856 {
    private static final class_2940<Integer> TIER_ID =
            class_2945.method_12791(ThrowingDiscEntity.class, class_2943.field_13327);

    private static final int OUT_TICKS = 12;
    private static final int BOUNCE_BONUS_TICKS = 5;
    private static final int MAX_BOUNCES = 6;
    private static final double RETURN_PULL = 0.3;
    private static final double RETURN_DRAG = 0.88;
    private static final double RETURN_MAX_SPEED = 1.7;
    private static final double CATCH_RADIUS_SQ = 1.5 * 1.5;
    private static final int MIN_CATCH_TICKS = 5;
    private static final int MAX_FLIGHT_TICKS = 400;
    private static final int MAX_HITS_PER_TARGET = 3;
    private static final int HIT_GAP_TICKS = 6;

    private class_1799 stack = class_1799.field_8037;
    private UUID ownerId;
    private class_243 motion = class_243.field_1353;
    private boolean returning;
    private int outTicksLeft = OUT_TICKS;
    private int bounces;
    private int flightTicks;
    /** Per target: {hit count, tick of last hit}. Not saved; a reload simply resets the limits. */
    private final Map<UUID, int[]> hits = new HashMap<>();

    private class_1799 displayStack;
    private DiscTier displayTier;

    public ThrowingDiscEntity(class_1299<? extends ThrowingDiscEntity> type, class_1937 world) {
        super(type, world);
        this.field_5960 = true;
    }

    /** Server side: start a fresh throw. */
    public void launch(class_1657 owner, class_1799 thrown, DiscTier tier) {
        this.ownerId = owner.method_5667();
        this.stack = thrown;
        this.field_6011.method_12778(TIER_ID, tier.ordinal());
        class_243 look = owner.method_5828(1.0F).method_1029();
        this.motion = look.method_1021(tier.speed * 0.8);
        this.outTicksLeft = OUT_TICKS;
        class_243 start = new class_243(owner.method_23317(), owner.method_23320() - 0.15, owner.method_23321()).method_1019(look.method_1021(0.6));
        this.method_5814(start.field_1352, start.field_1351, start.field_1350);
        this.method_18799(this.motion);
    }

    public DiscTier getTier() {
        return DiscTier.byIndex(this.field_6011.method_12789(TIER_ID));
    }

    @Override
    public class_1799 method_7495() {
        if (!stack.method_7960()) {
            return stack;
        }
        // Client side (and fallback): show a plain stack of this disc's tier, cached.
        DiscTier tier = getTier();
        if (displayStack == null || displayTier != tier) {
            displayStack = new class_1799(tier.item);
            displayTier = tier;
        }
        return displayStack;
    }

    @Override
    public void method_5773() {
        super.method_5773();
        class_1937 world = method_73183();
        if (world.method_8608()) {
            // Cheap extrapolation between server position updates.
            class_243 v = method_18798();
            method_5814(method_23317() + v.field_1352, method_23318() + v.field_1351, method_23321() + v.field_1350);
            return;
        }
        if (!(world instanceof class_3218 serverWorld)) {
            return;
        }

        flightTicks++;
        if (flightTicks > MAX_FLIGHT_TICKS) {
            dropAndRemove(serverWorld);
            return;
        }

        class_1657 owner = ownerId == null ? null : serverWorld.method_18470(ownerId);
        if (returning) {
            if (owner == null || !owner.method_5805()) {
                dropAndRemove(serverWorld);
                return;
            }
            steerHome(owner);
        } else if (outTicksLeft-- <= 0) {
            returning = true;
        }

        if (!returning) {
            bounceOffBlocks(serverWorld);
        }

        class_243 next = method_73189().method_1019(motion);
        method_5814(next.field_1352, next.field_1351, next.field_1350);
        method_18799(motion);

        hitMobs(serverWorld, owner);

        if (returning && owner != null && flightTicks > MIN_CATCH_TICKS
                && method_73189().method_1025(owner.method_73189().method_1031(0, owner.method_17682() * 0.5, 0))
                        < CATCH_RADIUS_SQ) {
            catchBy(owner);
        }
    }

    private void steerHome(class_1657 owner) {
        class_243 target = owner.method_73189().method_1031(0, owner.method_17682() * 0.6, 0);
        class_243 toOwner = target.method_1020(method_73189());
        double dist = toOwner.method_1033();
        if (dist > 1.0E-4) {
            motion = motion.method_1021(RETURN_DRAG).method_1019(toOwner.method_1021(RETURN_PULL / dist));
        }
        double speed = motion.method_1033();
        if (speed > RETURN_MAX_SPEED) {
            motion = motion.method_1021(RETURN_MAX_SPEED / speed);
        }
    }

    /** Tests each axis separately so the disc reflects off the face it actually hit. */
    private void bounceOffBlocks(class_3218 world) {
        class_243 p = method_73189();
        boolean hx = blocked(world, p.field_1352 + motion.field_1352, p.field_1351, p.field_1350);
        boolean hy = blocked(world, p.field_1352, p.field_1351 + motion.field_1351, p.field_1350);
        boolean hz = blocked(world, p.field_1352, p.field_1351, p.field_1350 + motion.field_1350);
        if (!hx && !hy && !hz && blocked(world, p.field_1352 + motion.field_1352, p.field_1351 + motion.field_1351, p.field_1350 + motion.field_1350)) {
            hx = true;
            hy = true;
            hz = true;
        }
        if (!hx && !hy && !hz) {
            return;
        }
        motion = new class_243(hx ? -motion.field_1352 : motion.field_1352, hy ? -motion.field_1351 : motion.field_1351, hz ? -motion.field_1350 : motion.field_1350);
        bounces++;
        outTicksLeft += BOUNCE_BONUS_TICKS;
        if (bounces >= MAX_BOUNCES) {
            returning = true;
        }
        world.method_8396(null, method_24515(), class_3417.field_26980,
                class_3419.field_15248, 0.5F, getTier().pitch);
    }

    private static boolean blocked(class_3218 world, double x, double y, double z) {
        class_2338 pos = class_2338.method_49637(x, y, z);
        if (!world.method_22340(pos)) {
            return true;
        }
        class_2680 state = world.method_8320(pos);
        return !state.method_26220(world, pos).method_1110();
    }

    private void hitMobs(class_3218 world, class_1657 owner) {
        class_238 box = method_5829().method_1014(0.35);
        List<class_1309> found = world.method_8390(class_1309.class, box,
                e -> e.method_5805() && !e.method_7325() && !e.method_5667().equals(ownerId));
        if (found.isEmpty()) {
            return;
        }
        DiscTier tier = getTier();
        for (class_1309 target : found) {
            int[] record = hits.computeIfAbsent(target.method_5667(), k -> new int[] {0, -HIT_GAP_TICKS});
            if (record[0] >= MAX_HITS_PER_TARGET || flightTicks - record[1] < HIT_GAP_TICKS) {
                continue;
            }
            record[0]++;
            record[1] = flightTicks;
            // The owner is the attacker, so Nhil's kill-experience logic credits the thrower.
            target.method_64397(world, world.method_48963().method_48811(this, owner), tier.damage);
            world.method_8396(null, target.method_24515(), class_3417.field_14706,
                    class_3419.field_15248, 0.7F, tier.pitch);
        }
    }

    /** Returns the disc to its owner, spending one point of durability per completed throw. */
    private void catchBy(class_1657 owner) {
        class_1799 back = stack.method_7972();
        if (!back.method_7960()) {
            if (back.method_7963()) {
                int worn = back.method_7919() + 1;
                if (worn >= back.method_7936()) {
                    method_31472();
                    return;
                }
                back.method_7974(worn);
            }
            owner.method_7270(back);
        }
        method_31472();
    }

    private void dropAndRemove(class_3218 world) {
        if (!stack.method_7960()) {
            world.method_8649(new class_1542(world, method_23317(), method_23318(), method_23321(), stack.method_7972()));
        }
        method_31472();
    }

    @Override
    public boolean method_64397(class_3218 world, class_1282 source, float amount) {
        return false;
    }

    @Override
    protected void method_5693(class_2945.class_9222 builder) {
        builder.method_56912(TIER_ID, 0);
    }

    @Override
    protected void method_5749(class_11368 view) {
        this.field_6011.method_12778(TIER_ID, view.method_71424("tier", 0));
        this.returning = view.method_71433("returning", false);
        this.outTicksLeft = view.method_71424("outTicksLeft", OUT_TICKS);
        this.bounces = view.method_71424("bounces", 0);
        this.flightTicks = view.method_71424("flightTicks", 0);
        this.motion = new class_243(view.method_71422("mx", 0), view.method_71422("my", 0), view.method_71422("mz", 0));
        this.stack = view.method_71426("stack", class_1799.field_24671).orElse(class_1799.field_8037);
        this.ownerId = view.method_71441("owner").map(ThrowingDiscEntity::parseUuid).orElse(null);
    }

    @Override
    protected void method_5652(class_11372 view) {
        view.method_71465("tier", getTier().ordinal());
        view.method_71472("returning", returning);
        view.method_71465("outTicksLeft", outTicksLeft);
        view.method_71465("bounces", bounces);
        view.method_71465("flightTicks", flightTicks);
        view.method_71463("mx", motion.field_1352);
        view.method_71463("my", motion.field_1351);
        view.method_71463("mz", motion.field_1350);
        if (!stack.method_7960()) {
            view.method_71468("stack", class_1799.field_24671, stack);
        }
        if (ownerId != null) {
            view.method_71469("owner", ownerId.toString());
        }
    }

    private static UUID parseUuid(String text) {
        try {
            return UUID.fromString(text);
        } catch (IllegalArgumentException e) {
            return null;
        }
    }
}
