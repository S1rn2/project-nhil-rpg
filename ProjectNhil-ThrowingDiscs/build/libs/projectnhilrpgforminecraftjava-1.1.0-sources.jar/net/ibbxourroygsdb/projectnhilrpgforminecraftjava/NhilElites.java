package net.ibbxourroygsdb.projectnhilrpgforminecraftjava;

import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerEntityEvents;
import net.minecraft.class_124;
import net.minecraft.class_1282;
import net.minecraft.class_1309;
import net.minecraft.class_1322;
import net.minecraft.class_1324;
import net.minecraft.class_1569;
import net.minecraft.class_1799;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_5134;

/**
 * Marks a small share of hostile mobs as Nhil elites.
 *
 * <p>The marker is written when a mob enters the world and read again on death, so the
 * variant and its reward always agree. Everything happens on entity load and death,
 * never in a per-tick scan.
 */
public final class NhilElites {
    private NhilElites() {
    }

    /** Chance for a freshly loaded monster to become an elite. */
    private static final float ELITE_CHANCE = 0.06F;
    /** Command tag used as the marker, persisted with the entity and visible through /tag. */
    public static final String MARKER = "nhil_elite";

    private static final class_2960 HEALTH_ID = class_2960.method_60655(PGPlugin.MOD_ID, "elite_vitality");
    private static final class_2960 DAMAGE_ID = class_2960.method_60655(PGPlugin.MOD_ID, "elite_might");

    public static void register() {
        // Producer: decide the variant once, when the mob enters the world.
        ServerEntityEvents.ENTITY_LOAD.register((entity, world) -> {
            if (!(entity instanceof class_1309 living) || !(entity instanceof class_1569)) {
                return;
            }
            if (living.method_5752().contains(MARKER)) {
                // Already an elite, for example after a chunk reload. Keep boons, never heal.
                applyBoons(living, false);
                living.method_5834(true);
                return;
            }
            if (living.method_59922().method_43057() >= ELITE_CHANCE) {
                return;
            }
            living.method_5780(MARKER);
            applyBoons(living, true);
            living.method_5665(class_2561.method_43470("Nhil Elite ").method_27692(class_124.field_1076)
                    .method_10852(living.method_5864().method_5897()));
            living.method_5880(false);
            living.method_5834(true);
        });

        // Consumer: pay out extra progression for the marked variant.
        ServerLivingEntityEvents.AFTER_DEATH.register((entity, source) -> {
            if (!(entity instanceof class_1569) || !entity.method_5752().contains(MARKER)) {
                return;
            }
            class_3222 killer = killerOf(source);
            if (killer == null) {
                return;
            }
            NhilProgress.grantExperience(killer, 8, "elite");
            killer.method_7353(class_2561.method_43470("Elite slain. Its rune power is yours.")
                    .method_27692(class_124.field_1076), true);
            if (killer.method_59922().method_43057() < 0.5F) {
                class_1799 tonic = new class_1799(NhilContent.RUNE_TONIC);
                if (!killer.method_31548().method_7394(tonic)) {
                    killer.method_7328(tonic, false);
                }
            }
        });
    }

    /** Bonus health and attack power for an elite. Safe to call more than once. */
    private static void applyBoons(class_1309 entity, boolean heal) {
        if (!(entity.method_73183() instanceof class_3218)) {
            return;
        }
        class_1324 health = entity.method_5996(class_5134.field_23716);
        if (health != null && health.method_6199(HEALTH_ID) == null) {
            health.method_26837(new class_1322(
                    HEALTH_ID, 0.5, class_1322.class_1323.field_6330));
            if (heal) {
                entity.method_6033(entity.method_6063());
            }
        }
        class_1324 damage = entity.method_5996(class_5134.field_23721);
        if (damage != null && damage.method_6199(DAMAGE_ID) == null) {
            damage.method_26837(new class_1322(
                    DAMAGE_ID, 0.35, class_1322.class_1323.field_6330));
        }
    }

    private static class_3222 killerOf(class_1282 source) {
        if (source.method_5529() instanceof class_3222 player) {
            return player;
        }
        return null;
    }
}
