package net.ibbxourroygsdb.projectnhilrpgforminecraftjava;

import java.util.List;
import net.minecraft.class_10124;
import net.minecraft.class_10128;
import net.minecraft.class_10132;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1792;
import net.minecraft.class_1839;
import net.minecraft.class_3417;
import net.minecraft.class_4174;

/**
 * Factory for the Rune Tonic: a drinkable field remedy.
 *
 * <p>Built from vanilla consumable components so it works in every game mode.
 */
final class NhilConsumables {
    private NhilConsumables() {
    }

    /** Two hearts of healing plus short regeneration, at the cost of a shard. */
    static class_1792.class_1793 runeTonic(class_1792.class_1793 settings) {
        class_4174 food = new class_4174(2, 1.0F, false);
        class_10124 consumable = class_10128.method_62859()
                .method_62852(1.4F)
                .method_62853(class_1839.field_8946)
                .method_62855(class_3417.field_20613)
                .method_62856(true)
                .method_62854(new class_10132(List.of(
                        new class_1293(class_1294.field_5924, 100, 0),
                        new class_1293(class_1294.field_5907, 60, 0)), 1.0F))
                .method_62851();
        return settings.method_62833(food, consumable);
    }
}
