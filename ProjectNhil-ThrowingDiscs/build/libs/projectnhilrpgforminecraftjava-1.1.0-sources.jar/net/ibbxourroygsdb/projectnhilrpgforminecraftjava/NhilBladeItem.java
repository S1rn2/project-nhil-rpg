package net.ibbxourroygsdb.projectnhilrpgforminecraftjava;

import java.util.List;
import net.minecraft.class_124;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_238;
import net.minecraft.class_2398;
import net.minecraft.class_2561;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3417;
import net.minecraft.class_3419;

/**
 * The Nhil Blade, a sword that can release a short rune wave.
 *
 * <p>The wave is server side only, covers a small radius and respects a cooldown,
 * so it stays cheap in multiplayer and never scans the world.
 */
public class NhilBladeItem extends class_1792 {
    /** Reach of the rune wave, in blocks. */
    private static final double WAVE_RADIUS = 4.0D;
    /** Damage dealt to each creature caught in the wave. */
    private static final float WAVE_DAMAGE = 5.0F;
    /** Cooldown between waves, in ticks. */
    private static final int COOLDOWN_TICKS = 240;

    public NhilBladeItem(class_1793 settings) {
        super(settings);
    }

    @Override
    public class_1269 method_7836(class_1937 world, class_1657 user, class_1268 hand) {
        if (world.method_8608() || !(user instanceof class_3222 player)) {
            return class_1269.field_5812;
        }
        class_1799 stack = player.method_5998(hand);
        if (player.method_7357().method_7904(stack)) {
            return class_1269.field_5814;
        }
        if (!(world instanceof class_3218 serverWorld)) {
            return class_1269.field_5811;
        }

        int level = NhilProgress.of(player).level();
        class_238 area = player.method_5829().method_1014(WAVE_RADIUS);
        List<class_1309> targets = serverWorld.method_8390(class_1309.class, area,
                candidate -> candidate != player && candidate.method_5805() && !candidate.method_7325());

        int struck = 0;
        int cap = Math.min(targets.size(), 6);
        for (int index = 0; index < cap; index++) {
            class_1309 target = targets.get(index);
            if (target.method_64397(serverWorld, serverWorld.method_48963().method_48802(player),
                    WAVE_DAMAGE + level * 0.2F)) {
                struck++;
            }
        }

        serverWorld.method_8396(null, player.method_24515(), class_3417.field_14706,
                class_3419.field_15248, 0.9F, 1.4F);
        serverWorld.method_65096(class_2398.field_11227, player.method_23317(), player.method_23318() + 1.0,
                player.method_23321(), 1, 0.0, 0.0, 0.0, 0.0);
        player.method_7357().method_62835(stack, COOLDOWN_TICKS);

        if (struck > 0) {
            player.method_7353(class_2561.method_43470("Rune wave strikes " + struck + " for " + (int) WAVE_DAMAGE + ".")
                    .method_27692(class_124.field_1076), true);
        } else {
            player.method_7353(class_2561.method_43470("The rune wave finds nothing to cut.")
                    .method_27692(class_124.field_1080), true);
        }
        return class_1269.field_5812;
    }
}
