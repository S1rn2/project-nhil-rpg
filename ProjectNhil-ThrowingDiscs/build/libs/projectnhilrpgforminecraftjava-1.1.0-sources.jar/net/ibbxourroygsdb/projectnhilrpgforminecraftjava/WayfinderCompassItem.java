package net.ibbxourroygsdb.projectnhilrpgforminecraftjava;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_124;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2378;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_3195;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_5321;
import net.minecraft.class_6880;
import net.minecraft.class_6885;
import net.minecraft.class_7058;
import net.minecraft.class_7924;
import com.mojang.datafixers.util.Pair;

/**
 * The Wayfinder Compass: reveals the nearest ruin or abandoned site.
 */
public class WayfinderCompassItem extends class_1792 {
    /** Search radius in chunks. */
    private static final int SEARCH_RADIUS_CHUNKS = 60;
    /** Cooldown in ticks between uses. */
    private static final int COOLDOWN_TICKS = 200;

    private static final List<class_5321<class_3195>> RUIN_SITES = List.of(
            class_7058.field_37192,
            class_7058.field_37193,
            class_7058.field_37163,
            class_7058.field_37164,
            class_7058.field_37165,
            class_7058.field_43326,
            class_7058.field_37173,
            class_7058.field_37172,
            class_7058.field_37174,
            class_7058.field_37177,
            class_7058.field_37168,
            class_7058.field_37169,
            class_7058.field_37178,
            class_7058.field_38428,
            class_7058.field_47411,
            class_7058.field_37175,
            class_7058.field_37185,
            class_7058.field_37171,
            class_7058.field_37179,
            class_7058.field_37180,
            class_7058.field_37181);

    public WayfinderCompassItem(class_1793 settings) {
        super(settings);
    }

    @Override
    public class_1269 method_7836(class_1937 world, class_1657 user, class_1268 hand) {
        if (world.method_8608() || !(user instanceof class_3222 player)) {
            return class_1269.field_5812;
        }
        class_3218 serverWorld = player.method_51469();
        if (player.method_7357().method_7904(player.method_5998(hand))) {
            return class_1269.field_5814;
        }
        Pair<class_2338, class_6880<class_3195>> found = locate(serverWorld, player);
        if (found == null) {
            player.method_7353(class_2561.method_43470("The needle spins. No ruins within reach.")
                    .method_27692(class_124.field_1080), true);
            return class_1269.field_5814;
        }

        class_2338 target = found.getFirst();
        class_2960 id = found.getSecond().method_40230()
                .map(class_5321::method_29177)
                .orElse(class_2960.method_60656("ruins"));
        String pretty = prettify(id.method_12832());
        String direction = directionFrom(player, target);
        int distance = (int) Math.round(Math.sqrt(target.method_40081(player.method_23317(), player.method_23318(), player.method_23321())));

        player.method_7353(class_2561.method_43470("Wayfinder: " + pretty)
                .method_27692(class_124.field_1065)
                .method_10852(class_2561.method_43470(" (" + distance + " blocks " + direction + ")").method_27692(class_124.field_1080)), false);
        player.method_7353(class_2561.method_43470("Recorded a new landmark.").method_27692(class_124.field_1054), true);

        player.method_7357().method_62835(player.method_5998(hand), COOLDOWN_TICKS);
        NhilProgress.grantExperience(player, 4, "landmark");
        NhilProgress.registerDiscovery(player, id.toString());
        return class_1269.field_5812;
    }

    private static Pair<class_2338, class_6880<class_3195>> locate(class_3218 world, class_1657 player) {
        try {
            class_2378<class_3195> registry = world.method_30349().method_30530(class_7924.field_41246);
            List<class_6880<class_3195>> entries = new ArrayList<>();
            for (class_5321<class_3195> key : RUIN_SITES) {
                registry.method_10223(key.method_29177()).ifPresent(entries::add);
            }
            if (entries.isEmpty()) {
                return null;
            }
            class_6885<class_3195> candidates = class_6885.method_40242(entries);
            return world.method_14178().method_12129().method_12103(
                    world, candidates, player.method_24515(), SEARCH_RADIUS_CHUNKS, true);
        } catch (RuntimeException exception) {
            PGPlugin.LOGGER.warn("Wayfinder search failed", exception);
            return null;
        }
    }

    private static String directionFrom(class_1657 player, class_2338 target) {
        double dx = target.method_10263() - player.method_23317();
        double dz = target.method_10260() - player.method_23321();
        if (Math.abs(dx) > Math.abs(dz)) {
            return dx > 0 ? "east" : "west";
        }
        return dz > 0 ? "south" : "north";
    }

    static String prettify(String path) {
        String spaced = path.replace('_', ' ');
        if (spaced.isEmpty()) {
            return "ruins";
        }
        return Character.toUpperCase(spaced.charAt(0)) + spaced.substring(1);
    }

    @Override
    public boolean method_7886(class_1799 stack) {
        return true;
    }
}
